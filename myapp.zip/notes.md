# Sample NodeJS application for GitHub Actions 

Sample workflow to build and deploy node js app. 

### Links:

sample aws action usage - v1 workflow: https://gist.github.com/pahud/4bdc6cde7b55c4fb8bd8c886dd57787e


use aws cli instead of eb cli: https://stackoverflow.com/questions/37644881/how-to-use-aws-cli-with-elastic-beanstalk
